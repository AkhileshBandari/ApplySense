import json

from ai_engine.fallback_manager import AIFallbackManager
from ai_engine import prompts


class AIEvaluationEngine:
    """A lightweight evaluation engine inspired by Career-Ops scoring logic."""

    def evaluate_job(self, job: dict | None = None, resume_text: str | None = None, profile: object | None = None) -> dict:
        job = job or {}
        resume_text = resume_text or ""
        description = (job.get("description") or "").lower()
        resume_lower = resume_text.lower()

        overlap = sum(1 for keyword in ["python", "django", "backend", "api", "rest"] if keyword in description and keyword in resume_lower)
        score = min(100, 45 + overlap * 12)
        grade = self._grade(score)
        summary = f"Estimated fit for {job.get('title', 'this role')}"
        matched_keywords = [keyword for keyword in ["python", "django", "backend", "api", "rest"] if keyword in description and keyword in resume_lower]

        try:
            ai = AIFallbackManager()
            response = ai.generate_content(
                prompts.MATCH_SCORE_SYSTEM_PROMPT,
                f"Resume:\n{resume_text}\n\nJob Description:\n{job.get('description', '')}",
                response_format_json=True,
            )
            parsed = self._parse_json(response)
            if isinstance(parsed, dict):
                score = int(parsed.get("score", score) or score)
                grade = self._grade(score)
                summary = parsed.get("explanation", summary)
        except Exception:
            pass

        return {
            "score": max(0, min(100, score)),
            "grade": grade,
            "summary": summary,
            "matched_keywords": matched_keywords,
        }

    @staticmethod
    def _parse_json(response_text: str) -> dict:
        cleaned = response_text.strip()
        if cleaned.startswith("```json"):
            cleaned = cleaned.replace("```json", "", 1)
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
        cleaned = cleaned.strip()
        try:
            return json.loads(cleaned)
        except Exception:
            return {"score": 0, "explanation": response_text}

    @staticmethod
    def _grade(score: int) -> str:
        if score >= 85:
            return "A"
        if score >= 70:
            return "B"
        if score >= 55:
            return "C"
        if score >= 40:
            return "D"
        return "F"
